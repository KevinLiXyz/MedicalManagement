using System.Windows.Controls;

namespace MedicalImagingSystem.Views
{
    public partial class PatientListView : UserControl
    {
        public PatientListView()
        {
            InitializeComponent();
        }
    }
}