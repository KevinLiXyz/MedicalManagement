﻿namespace MedicalImagingSystem.Services
{
	public class Class1
	{

	}
}
