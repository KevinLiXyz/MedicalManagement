﻿namespace MedicalImagingSystem.Models
{
	public class Class1
	{

	}
}
